package Golf;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JPanel;
import javax.swing.Timer;



public class GolfGame extends JPanel implements MouseListener, ActionListener,KeyListener{

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Timer Timer;
    private int delay = 8;
    private int ballX = 100;
    private int ballY = 420;
    private int holeX = 400;
    private int holeY = 100;
    private boolean holeReached = false;
    private boolean mouseCheck = false;
    private int strokes = 0;
    private double ballVelocityX = 0;
    private double ballVelocityY = 0;
    private Map map;

    public GolfGame() {
    	map = new Map();
    	addKeyListener(this);
    	addMouseListener(this);
        setFocusable(true);
        setFocusTraversalKeysEnabled(false);
        Timer = new Timer(delay, this);
        Timer.start();
    }
            public void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.setColor(Color.black);
                g.fillRect(0, 0, 800, 600);
                map.draw((Graphics2D) g);
                g.setColor(Color.white);
                g.fillOval(ballX, ballY, 10, 10);
                g.setColor(Color.red);
                g.fillOval(holeX, holeY, 30, 30);
                g.setColor(Color.white);
                g.drawRect(0, 0, 800, 600);
                g.drawString("Strokes: " + strokes, 600, 100);
                g.drawString("Press Space to retart", 600, 300);
                if (holeReached) {
                    g.drawString("You win!", 800/2 - 30, 600/2);
                    Timer.stop();
                }
                
            }
            
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                    	ballX = 100;
                    	ballY = 420;
                    	ballVelocityX = 0;
                    	ballVelocityY = 0;
                        strokes = 0; 
                        holeReached = false;
                        mouseCheck = true;
                        repaint();
                        Timer.start();
                }


                }        
 
            
    public void actionPerformed(ActionEvent e) {   
        if (!holeReached) {     
        	if(mouseCheck && (Math.max(Math.abs(ballVelocityX),Math.abs(ballVelocityY))<=2)) {
        		ballVelocityX=0;
        		ballVelocityY=0;
        		mouseCheck=false;
        	}}
 
       A:for (int i = 0; i < map.map.length; i++) {
            for (int j = 0; j < map.map[0].length; j++) {
                if (map.map[i][j] > 0) {
                    int wallX = j * map.wallWidth ;
                    int wallY = i * map.wallHeight ;
                    int wallHeight = map.wallHeight;
                    int wallWidth = map.wallWidth;
                    Rectangle rect = new Rectangle(wallX, wallY, wallWidth, wallHeight);
                    Rectangle ballrect = new Rectangle(ballX, ballY, 10, 10);
                    Rectangle wallrect = rect;
                    if (ballrect.intersects(wallrect)) {                   	
                   	 if (ballX  <wallrect.x + wallWidth &&  ballVelocityX<0 ) {
                      	ballVelocityX  = -ballVelocityX; 
                      	break A;
                      }                   	
                    	 if (ballX  <wallrect.x ) {
                        	ballVelocityX  = -ballVelocityX;                        
                        }
                    	 else {
                                ballVelocityY  = -ballVelocityY;                              
                        	}
                    	 break A;
                    }                   
                }
            }
        }
    	ballX += ballVelocityX;
        ballY += ballVelocityY;
        
        ballVelocityX *= 0.98;
        ballVelocityY *= 0.98;
        
      if (Math.abs(ballX - holeX) <= 10 && Math.abs(ballY - holeY) <= 10) {
    	  holeReached = true;
      }
      repaint();
    }
            
    public void mouseClicked(MouseEvent e) {
        if (e.getButton() == MouseEvent.BUTTON1 && ballVelocityX==0 && ballVelocityY==0) {
      
            double distance = Math.sqrt((e.getX() - ballX) * (e.getX() - ballX) 
            		+ (e.getY() - ballY) * (e.getY() - ballY));
            double speed = distance /25;
            ballVelocityX = (e.getX() - ballX) / distance * speed;
            ballVelocityY = (e.getY() - ballY) / distance * speed;
            

            if (Math.abs(ballVelocityX) > 20) {
                ballVelocityX = Math.signum(ballVelocityX) * 20;
            }
            if (Math.abs(ballVelocityY) > 20) {
                ballVelocityY = Math.signum(ballVelocityY) * 20;
            }

            strokes++;
            mouseCheck=true;
            
        }
    }

    public void mousePressed(MouseEvent e) {

    }

    public void mouseReleased(MouseEvent e) {

    }

    public void mouseEntered(MouseEvent e) {

    }

    public void mouseExited(MouseEvent e) {

    }
    
    public void keyReleased(KeyEvent e) {

    }


	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}


}
