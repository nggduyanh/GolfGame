package Golf;

import javax.swing.JFrame;

public class Main {

	public static void main(String[] args) {
		JFrame obj = new JFrame();
		GolfGame gg = new GolfGame();
		obj.setBounds(0, 0, 800, 600);
		obj.setTitle("Golf"); 
		obj.setResizable(false);
		obj.setVisible(true);
		obj.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		obj.add(gg);
	}

}
