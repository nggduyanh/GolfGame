package Golf;


import java.awt.Color;
import java.awt.Graphics2D;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Map {
	public int map[][];
    public int wallWidth=50;
    public int wallHeight=50;
    public int legth=0;  
    public  Map() {
    	try {
    		InputStream is = getClass().getResourceAsStream("/map.txt");
    		BufferedReader br = new BufferedReader(new InputStreamReader(is));
    		map = new int[10][10];
    		 for (int i=0;i<map.length;i++) {
    			 String line = br.readLine();
                 for (int j = 0; j < map[0].length; j++) {
                	 String numbers[] = line.trim().split(" ");
                	 int num = Integer.parseInt(numbers[j]);
                	 map[i][j] = num;
                 }
             }
    		br.close();
    	}catch(Exception e) { 		
    	}
    }

    public void draw(Graphics2D g) {
        for (int i = 0; i < map.length; i++) {
            for (int j = 0; j < map[0].length; j++) {
                if (map[i][j] > 0) {
                    g.setColor(Color.green);
                    g.fillRect(j * wallWidth, i * wallHeight, wallWidth , wallHeight );       
                }
            }

        }
    }
}

